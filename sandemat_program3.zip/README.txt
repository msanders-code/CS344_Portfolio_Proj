


How to compile:

make sure all files are in the folder and then run 'make' command.