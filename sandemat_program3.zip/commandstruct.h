#ifndef COMMAND_STRUCT_H
#define COMMAND_STRUCT_H


// Structure definition to parse a command 
struct command
{
	char* cmd;
	char* arguments[514];
	char* inputFile;
	char* outputFile;
	char* backGround;
};

// Union definition
struct information
{
	char* message;
	int value;
};

// Function to parse a user command line
struct information* parseCommand(char* command, int mode);

#endif